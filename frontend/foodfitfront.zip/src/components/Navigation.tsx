import React from 'react';
import { Box, Flex, Link as ChakraLink } from '@chakra-ui/react';
import { Link as RouterLink } from 'react-router-dom';
import { useAuthStore } from '../lib/store';

function Navigation() {
  const { isAuthenticated } = useAuthStore();

  return (
    <Box 
      bg="brand.500" 
      px={4} 
      py={3} 
      position="fixed"
      top={0}
      left={0}
      right={0}
      zIndex={1000}
      boxShadow="sm"
    >
      <Flex gap={4}>
        {!isAuthenticated && (
          <ChakraLink 
            as={RouterLink} 
            to="/" 
            color="white"
            _hover={{ color: 'brand.100' }}
            fontWeight="medium"
          >
            Login
          </ChakraLink>
        )}
        {isAuthenticated && (
          <>
            <ChakraLink 
              as={RouterLink} 
              to="/restaurants" 
              color="white"
              _hover={{ color: 'brand.100' }}
              fontWeight="medium"
            >
              Restaurants
            </ChakraLink>
            <ChakraLink 
              as={RouterLink} 
              to="/cart" 
              color="white"
              _hover={{ color: 'brand.100' }}
              fontWeight="medium"
            >
              Cart
            </ChakraLink>
            <ChakraLink 
              as={RouterLink} 
              to="/donate" 
              color="white"
              _hover={{ color: 'brand.100' }}
              fontWeight="medium"
            >
              Donate
            </ChakraLink>
          </>
        )}
      </Flex>
    </Box>
  );
}

export default Navigation;