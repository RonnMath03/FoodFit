import React from 'react';
import { Box, VStack, Heading, SimpleGrid, Text, Button, Image, Tag, HStack } from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';

const sampleRestaurants = [
  { 
    id: '1', 
    name: 'Punjab Dhaba', 
    cuisine: 'North Indian', 
    rating: '4.5',
    sustainability: {
      accuratePortions: '95%',
      carbonSaved: '120kg'
    },
    dietaryOptions: ['veg', 'non-veg'],
    avgPortionSize: 'Medium-Large'
  },
  { 
    id: '2', 
    name: 'Dakshin', 
    cuisine: 'South Indian', 
    rating: '4.3',
    sustainability: {
      accuratePortions: '92%',
      carbonSaved: '100kg'
    },
    dietaryOptions: ['veg', 'non-veg'],
    avgPortionSize: 'Medium'
  },
  { 
    id: '3', 
    name: 'Biryani House', 
    cuisine: 'Hyderabadi', 
    rating: '4.7',
    sustainability: {
      accuratePortions: '94%',
      carbonSaved: '110kg'
    },
    dietaryOptions: ['non-veg'],
    avgPortionSize: 'Large'
  },
  { id: '4', name: 'Chennai Express', cuisine: 'South Indian', rating: '4.4' },
  { id: '5', name: 'Gujarat Bhavan', cuisine: 'Gujarati', rating: '4.2' },
  { id: '6', name: 'Bengal Kitchen', cuisine: 'Bengali', rating: '4.6' },
  { id: '7', name: 'Mumbai Local', cuisine: 'Street Food', rating: '4.8' },
  { id: '8', name: 'Kerala House', cuisine: 'Kerala', rating: '4.5' }
];

function RestaurantListPage() {
  const navigate = useNavigate();

  return (
    <Box maxW="4xl" mx="auto" bg="white" p={4} sm={8} borderRadius="lg" boxShadow="md">
      <VStack spacing={4} align="stretch">
        <Heading size={{ base: "lg", md: "xl" }} color="brand.700" mb={2}>
          FoodFit Restaurants
        </Heading>
        <Text fontSize={{ base: "sm", md: "md" }} color="gray.600" mb={2}>
          Discover restaurants committed to portion optimization
        </Text>
        
        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={{ base: 4, md: 6 }}>
          {sampleRestaurants.map((restaurant) => (
            <Box 
              key={restaurant.id}
              p={4}
              borderWidth="1px"
              borderRadius="lg"
              _hover={{ shadow: 'md' }}
            >
              <VStack align="stretch" spacing={2}>
                <Heading size={{ base: "sm", md: "md" }} color="brand.600">
                  {restaurant.name}
                </Heading>
                <Text fontSize={{ base: "sm", md: "md" }} color="gray.600">
                  {restaurant.cuisine}
                </Text>
                <HStack flexWrap="wrap" spacing={2}>
                  <Text color="brand.500" fontSize={{ base: "sm", md: "md" }}>
                    ★ {restaurant.rating}
                  </Text>
                  <Tag colorScheme="green" size="sm">
                    Portion Accuracy: {restaurant.sustainability?.accuratePortions || 'N/A'}
                  </Tag>
                </HStack>
                <Button 
                  size={{ base: "sm", md: "md" }}
                  bg="brand.500"
                  color="white"
                  onClick={() => navigate(`/menu/${restaurant.id}`)}
                  _hover={{ bg: 'brand.600' }}
                >
                  View Menu
                </Button>
              </VStack>
            </Box>
          ))}
        </SimpleGrid>
      </VStack>
    </Box>
  );
}

export default RestaurantListPage;